using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using GestaApp.Models;
using GestaApp.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace GestaApp.Controllers
{
    [Route("[controller]")]
    [Route("[controller]/[action]")]
    public class categoryController : Controller
    {
        // private readonly ILogger<categoryController> _logger;

        private readonly gwapocarloContext _context;

        public categoryController(gwapocarloContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View(_context.Categories.ToList());
        }


        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Category ctg)
        {
            _context.Categories.Add(ctg);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Update(Category category)
        {
            if(ModelState.IsValid)
            {
                _context.Categories.Update(category);
                _context.SaveChanges();

                return RedirectToAction("Index");
            }
            return View(category);
        }

        public IActionResult Update(int? id)
        {
            if(id == null)
            {
                return RedirectToAction("Index");
            }
            
            var category = _context.Categories.Where(q => q.Id == id).FirstOrDefault();
            return View(category);
        }

               public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var category = await _context.Categories
                .FirstOrDefaultAsync(m => m.Id == id);
            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        // POST: Category/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var category = await _context.Categories.FindAsync(id);
            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}