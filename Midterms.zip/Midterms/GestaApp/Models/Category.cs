﻿using System;
using System.Collections.Generic;

namespace GestaApp.Models
{
    public partial class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
